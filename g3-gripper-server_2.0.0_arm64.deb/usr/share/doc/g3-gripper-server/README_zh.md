# G3 夹爪 C++ 服务端

本目录提供完整的 C++17 服务端、CMake 构建代码、ARM64 交叉编译脚本和 Debian 安装包。运行时不需要 Python、python-can、pip 或 Python gRPC。PC 上现有的 `G3_client` Python 客户端继续使用，接口与默认端口 `50008` 不变。

## 1. 交付文件

| 内容 | 路径 |
|---|---|
| 源码与编译脚本归档 | `artifacts/g3-gripper-server_2.0.0_source.tar.gz`（由 `scripts/package_source.sh` 生成） |
| ARM64 安装包 | `artifacts/g3-gripper-server_2.0.0_arm64.deb` |
| 安装包 SHA-256 | `artifacts/g3-gripper-server_2.0.0_arm64.deb.sha256` |
| CAN-FD 及夹爪功能代码 | `include/g3/gripper.hpp`、`src/gripper.cpp`、`src/socketcan.cpp` |
| gRPC 服务及入口 | `include/g3/service.hpp`、`src/service.cpp`、`src/main.cpp` |
| 原有兼容协议 | `proto/gripper.proto`，与 `../G3_client/dmgripper/gripper.proto` 保持一致 |
| 本机构建 | `CMakeLists.txt`、`build.sh` |
| x86_64 → ARM64 构建 | `scripts/build_arm64.sh`、`scripts/build_arm64_container.sh`、`cmake/aarch64-linux-gnu.cmake`、`packaging/Dockerfile.arm64` |
| deb 打包 | `scripts/package_deb.sh`、`packaging/` |
| 部署 | `deploy.sh`、`gripper.service`、`can_restart.sh` |
| 自动测试 | `tests/`，模拟传输与回环 gRPC 测试，不连接实际夹爪 |

旧 Python 服务端及其 wheel 安装文件已移除，历史实现仍可通过 Git 查看。业务功能由 C++ 实现；Shell 仅用于编译、打包、安装和配置操作系统 CAN 接口。

## 2. 离线包与系统要求

交付包按 **Ubuntu 20.04 ARM64** 构建，目标设备需具备正常的 Ubuntu 基础系统、dpkg、glibc、systemd 和 SocketCAN-FD 驱动。无需网络，无需预装 gRPC、protobuf、C++ 运行库或 iproute2。

单个 deb 包含 C++ 服务程序、gRPC、protobuf、C++ 运行库、OpenSSL、c-ares、zlib，以及 CAN 配置所需的 `ip` 程序和以上程序的全部非 glibc 动态依赖。第三方版本清单与许可证安装到 `/usr/share/doc/g3-gripper-server/`。操作系统的 glibc、内核和 systemd 使用设备现有版本；所需 glibc 下限由 ELF 符号扫描写入 deb，可查看：

```bash
dpkg-deb -f artifacts/g3-gripper-server_2.0.0_arm64.deb Architecture Depends
```

**已有兼容依赖优先使用。** 启动器先以 `LD_BIND_NOW=1` 检查系统库能否加载程序：成功则直接使用系统库；缺失或符号不兼容时，切换到包内 `/usr/lib/g3-gripper/bundled/` 的完整依赖集合。系统已有可运行的 `ip` 也会优先复用。不会安装或覆盖系统 gRPC/protobuf 包，不会调用 apt、pip 或嵌套执行 dpkg 安装依赖。

当前包的构建和离线验证基线为 Ubuntu 20.04 ARM64。远端发行版尚未确认；其他发行版仍需实机验收，ARM32、x86_64 或 musl/Alpine 不适用。

## 3. 在远端离线安装

只需把这一个 deb 拷贝到 ARM64 设备并执行：

```bash
sudo dpkg -i ./g3-gripper-server_2.0.0_arm64.deb
sudo systemctl status gripper.service --no-pager
sudo journalctl -u gripper.service -n 80 --no-pager
```

**安装和运行都不需要联网，也不需要另行执行 `apt --fix-broken install`。** 完整源码在设备上时，也可执行 `bash deploy.sh`，内部使用相同的 `dpkg -i` 命令。

安装时先验证服务程序和 `ip` 的运行库可加载，再注册、启用并尝试启动 `gripper.service`。默认先配置 `can0`，然后监听端口 `50008`；真正连接夹爪发生在客户端 `connect()` 时。如果 CAN 接口不存在，服务会记录错误并每 5 秒重试，需要核对设备驱动与接口名称。

可查看实际使用哪套依赖：

```bash
/usr/bin/g3-gripper-server --runtime-info
/usr/libexec/g3-gripper/ip --runtime-info
```

输出 `runtime=system` 表示复用系统环境，`runtime=bundled` 表示使用包内依赖。必要时可通过 `G3_RUNTIME_MODE=bundled` 强制使用随包测试过的完整依赖；默认值为 `auto`。

旧部署若在 `/etc/systemd/system/gripper.service` 中使用 `python ... server.py`，安装脚本会停止旧服务，将旧 unit 保存为 `gripper.service.python-backup`，随后启用包内的新 unit。其他自定义 unit 不会被自动覆盖，可用 `systemctl cat gripper.service` 检查是否遮蔽了 `/lib/systemd/system/gripper.service`。

### 配置与日常管理

配置文件为 `/etc/default/g3-gripper-server`：

```ini
G3_LISTEN=[::]:50008
G3_CONFIGURE_CAN=1
G3_CAN_INTERFACE=can0
G3_CAN_BITRATE=1000000
G3_CAN_DBITRATE=5000000
G3_CAN_SAMPLE_POINT=0.80
G3_CAN_DSAMPLE_POINT=0.75
```

修改后执行：

```bash
sudo systemctl restart gripper.service
sudo journalctl -u gripper.service -f
```

CAN 已由其他服务配置时，设置 `G3_CONFIGURE_CAN=0`。自动配置会将指定接口 down/up，并设置 `fd on restart-ms 100`。客户端的 `channel` 参数需与实际 CAN 接口匹配；`motor_id` 仍由客户端连接请求传入。

服务使用 root 配置 CAN，并使用 `NoNewPrivileges`、只读系统目录等 systemd 限制。gRPC 沿用原来的局域网明文通信，不提供认证或 TLS。

```bash
sudo systemctl stop gripper.service       # 停止服务进程
sudo systemctl start gripper.service      # 启动服务
sudo dpkg -r g3-gripper-server         # 卸载，保留配置
sudo dpkg --purge g3-gripper-server          # 卸载并删除包管理的配置
```

**停止服务、断开连接和卸载包不会向夹爪自动发送 Stop/失能指令。** 如需停止机械动作，应先通过客户端显式调用 `Stop()` 并检查结果。

## 4. 从源码编译

### 在 ARM64 设备或本机原生编译

以下命令在对应构建机器上执行。ARM64 设备原生编译得到 ARM64 程序，x86_64 本机编译得到 x86_64 程序。

```bash
sudo apt update
sudo apt install build-essential cmake pkg-config \
  libgrpc++-dev libprotobuf-dev protobuf-compiler protobuf-compiler-grpc patchelf iproute2
cd G3_server
bash build.sh
./build/native/g3-gripper-server --version
./build/native/g3-gripper-server --listen 0.0.0.0:50008
```

`build.sh` 编译并执行自动测试。CMake 在构建目录生成 C++ protobuf/gRPC 文件，无需手工生成或提交生成代码。`protoc` 与链接的 protobuf 开发库须来自相容版本。

原生构建完成后打包（`ip` 必须与目标架构一致，交叉打包可用 `TARGET_IP` 指定）：

```bash
bash scripts/package_deb.sh build/native "$(dpkg --print-architecture)"
```

### 在 x86_64 上交叉编译 ARM64

需要可访问 Ubuntu 软件源的 Docker 环境，当前用户应有 Docker 权限：

```bash
cd G3_server
bash scripts/build_arm64.sh
```

此脚本会：

1. 构建 Ubuntu 20.04 交叉编译镜像，安装 AArch64 GCC、ARM64 gRPC/protobuf 和 QEMU。
2. 编译到 `build/arm64/`。
3. 用 QEMU 执行 ARM64 测试程序，并运行服务端 `--version`。
4. 收集服务和 `ip` 的完整非 glibc 动态依赖及许可证，生成 `artifacts/g3-gripper-server_2.0.0_arm64.deb` 和校验文件。

离线安装测试入口为 `scripts/test_offline_deb.sh`，在 `--network none` 的容器中使用干净的 ARM64 Ubuntu 根文件系统执行真实 `dpkg -i`，并验证依赖回退、系统依赖复用、服务启动和卸载。首次准备构建镜像及测试根文件系统需要构建机联网，远端部署不需要。

该流程不需要在宿主机全局注册 binfmt，也不会操作宿主机 CAN 接口或安装服务。可以通过 `BUILD_JOBS=8 bash scripts/build_arm64.sh` 调整并行编译数量。首次构建需要下载依赖，之后复用 Docker 缓存。由于 apt 软件源可更新，重建包的依赖补丁版本及 SHA-256 可能变化。

## 5. 功能和协议兼容性

通信链路为 `G3_client → gRPC → C++ 服务端 → SocketCAN-FD → 夹爪`。

CAN 使用标准帧，发送 ID 为 `0x600 + motor_id`，接收 ID 为 `0x200 + motor_id`，开启 FD 和 BRS。寄存器数据采用大端序，不带 Modbus 设备 ID 和 CRC；支持 `0x03` 读寄存器、`0x06` 写单寄存器、`0x10` 写多寄存器。CAN-FD 合法 DLC 以零补齐，读取最多 31 个寄存器，单次多写最多 29 个寄存器。

| gRPC 接口 | C++ 行为 |
|---|---|
| `Connect` / `Disconnect` | 建立 / 释放 CAN 连接及状态线程，连接时先读取一次设备反馈 |
| `Enable` / `Disable` | 写 `0x050F = 1 / 0` |
| `Initialization` / `Home` | 写 `0x0100 = 0xA5 / 1` |
| `Open` / `Close` | 目标位置 `1000 / 0` |
| `SetTargetPosition` | 写 `0x0103`，限制为 `0～1000` |
| `SetTargetSpeed` | 写 `0x0104`，限制为 `1～100` |
| `SetTargetForce` | 写 `0x0101`，限制为 `20～100` |
| `SetJog` | 写 `0x010A`，支持 `-1 / 0 / 1`，负值以 16 位补码发送 |
| `SetFollowMode` | 写 `0x0508 = 1 / 0` |
| `Stop` / `Resume` | 写 `0x0502 = 1 / 2` |
| `ClearError` | 写 `0x0503 = 1` |
| `GetAllState` | 返回周期采样的状态、有效性、数据年龄和解码文本 |
| `GetCurrentPosition` / `GetInitState` | 返回反馈位置 / 初始化状态及完整状态快照 |
| `GetCurrentForce` | 保持原兼容语义，返回电机电流反馈，不是力传感器数据 |

控制响应的 `success=true` 表示指令成功发送或重复指令被限频跳过，不代表机械运动完成。客户端等待方法及夹持状态判断方式不变，详见 [客户端 API](../G3_client/README_zh.md)。

服务端默认每 `0.05` 秒读取 `0x0200` 起的 6 个反馈寄存器；读取失败保留旧快照，超过 `stale_timeout_s` 后返回 `valid=false`、`stale=true`。反馈位置、速度、电流和错误码保留原始整数标度。设备错误非零不自动使通信状态无效。

### 并发和边界处理

- 单个服务端仍共享一个夹爪实例；新 `Connect` 重建连接，`Disconnect` 断开共享连接。多个客户端应由业务方协调控制权。
- gRPC 操作与连接生命周期串行化，底层 CAN 事务互斥；断开时唤醒并等待轮询线程退出，然后关闭 socket。
- 接收过滤器检查标准帧 ID，事务检查功能码、响应长度和写入回显；每次发送前清除已排队反馈。
- 重试次数指失败后的额外重试次数，重试间隔为 2 ms。重复指令仅在同一寄存器的最后成功值相同时限频；`A → B → A` 不会误跳过末次指令。
- 与旧服务端一致，RPC 中 `retry_count=0` 使用默认 `2`，`command_min_interval_s=0` 使用默认 `0.02`。NaN、无限值或超大超时配置返回失败。
- 为保证服务能退出，配置上限为：读间隔 10 秒、单次 CAN 超时 1 秒、重试 10 次、总 CAN 等待预算 3 秒（不含短暂重试休眠）、状态过期阈值 60 秒、限频间隔 10 秒。标准帧允许 `motor_id=0～511`。
- 协议没有事务序号，相同类型的迟到反馈不能完全与新响应区分；行为与原设备协议约束一致。

## 6. 本地 C++ 调用

业务应用也可直接链接 `g3_core`，使用 `g3::Gripper`，不启动 gRPC 服务。以下示例会操作实际夹爪，运行前需配置 CAN：

```cpp
#include "g3/gripper.hpp"
#include <iostream>

int main() {
    g3::Config config;
    config.channel = "can0";
    config.motor_id = 1;
    g3::Gripper gripper(config);
    auto result = gripper.connect();
    if (!result.success) { std::cerr << result.message << '\n'; return 1; }
    result = gripper.enable();
    if (!result.success) { std::cerr << result.message << '\n'; return 1; }
    if (gripper.state().init_state != 1) {
        result = gripper.initialize();
        if (!result.success) { std::cerr << result.message << '\n'; return 1; }
        result = gripper.wait_until_initialized(10);
        if (!result.success) { gripper.stop(); return 1; }
    }
    result = gripper.move_to(1000, 20, 50, true, 10, 10);
    const auto stopped = gripper.stop();
    if (!stopped.success) std::cerr << stopped.message << '\n';
    std::cout << result.message << '\n';
    gripper.disconnect();
    return result.success && stopped.success ? 0 : 1;
}
```

保存为 `example.cpp` 后，在与构建产物相同架构的机器上编译：

```bash
g++ -std=c++17 example.cpp -Iinclude build/native/libg3_core.a -pthread -o example
```

公共接口包括 `connect/disconnect`、`state/refresh_state`、使能、标定、回零、位置/速度/力、点动、跟随、停止/恢复、清错、`move_to`、等待初始化/位置以及 `read_registers/write_register/write_registers`。操作返回 `g3::Result{success, message}`，完整声明见 `include/g3/gripper.hpp`；底层寄存器接口仅供本地 C++ 使用，不新增远程 RPC。

析构函数会关闭连接并回收线程；与 Python 客户端一样，析构或等待超时不自动停止机械动作。不要在同一个 CAN 设备上同时运行直接调用程序和服务端。

## 7. 验证与限制

自动测试检查寄存器报文、值域限制、负向点动、单/多寄存器读写、失败重试、短帧拒绝、状态过期和恢复、未初始化运动拒绝、重复指令限频、并发读状态与断开、全部 20 个 gRPC 接口及并发重连。

模拟传输和 QEMU 验证不代替实际 CAN 控制器及夹爪验收。首次部署需确认设备的操作系统版本、CAN-FD 驱动/时序、设备 ID，再通过客户端验证初始化、开合、停止、反馈及故障处理。测试程序不安装进运行时 deb。
