# Sourced by the two launchers; all application logic remains in C++.
g3_libdir=/usr/lib/g3-gripper/bundled

g3_select_runtime() {
    g3_binary=$1
    g3_probe=$2
    case ${G3_RUNTIME_MODE:-auto} in
        auto|system|bundled) ;;
        *) echo 'G3_RUNTIME_MODE must be auto, system or bundled' >&2; return 1 ;;
    esac
    if [ "${G3_RUNTIME_MODE:-auto}" != bundled ] &&
       LD_BIND_NOW=1 "$g3_binary" "$g3_probe" >/dev/null 2>&1; then
        g3_runtime=system
        return 0
    fi
    if [ "${G3_RUNTIME_MODE:-auto}" = system ]; then
        echo 'Compatible system runtime libraries are unavailable.' >&2
        LD_BIND_NOW=1 "$g3_binary" "$g3_probe"
        return 1
    fi
    g3_runtime=bundled
    LD_LIBRARY_PATH="$g3_libdir" LD_BIND_NOW=1 "$g3_binary" "$g3_probe" >/dev/null || {
        echo 'Bundled runtime could not load; check the target architecture and glibc version.' >&2
        return 1
    }
}

g3_exec() {
    if [ "${1:-}" = --runtime-info ]; then
        printf 'runtime=%s binary=%s\n' "$g3_runtime" "$g3_binary"
        return 0
    fi
    if [ "$g3_runtime" = bundled ]; then
        export LD_LIBRARY_PATH="$g3_libdir"
    fi
    export LD_BIND_NOW=1
    exec "$g3_binary" "$@"
}
